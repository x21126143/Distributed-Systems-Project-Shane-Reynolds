package javax.annotation;

public @interface Generated {

	String value();

	String comments();

}
